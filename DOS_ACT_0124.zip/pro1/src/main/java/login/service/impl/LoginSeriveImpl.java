package login.service.impl;

import java.sql.SQLException;

import login.dao.LoginDao;
import login.dao.impl.LoginDaoImpl;
import login.model.LoginBean;
import login.service.LoginService;

public class LoginSeriveImpl implements LoginService{
	LoginDao dao;
    public LoginSeriveImpl() {
    	this.dao=new LoginDaoImpl();
    }
	@Override
	public LoginBean checkIdPassword(String userId, String password) throws SQLException {
		return dao.checkIdPassword(userId, password);
	}

}
