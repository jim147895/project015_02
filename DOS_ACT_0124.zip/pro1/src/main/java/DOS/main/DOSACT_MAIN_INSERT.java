package DOS.main;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import ACT.model.ACT;
import ACT.model.ACT_STATUS;
import ACT.model.ACT_TYPE;
import DOS.model.DOS;
import DOS.model.DOS_PICTURE;
import DOS.model.DOS_SPORT;
import DOS.util.HibernateUtils;

public class DOSACT_MAIN_INSERT {

	public DOSACT_MAIN_INSERT() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		SessionFactory factory = HibernateUtils.getSessionFactory();
	    Session session = factory.openSession();
	    Transaction tx = session.beginTransaction();
	    ACT act1=new ACT( null, 1, null, null, 0, null, null, null, null, 0, 0);
	    Set<ACT> actt = new HashSet<>(Arrays.asList(act1)); 
	    ACT_TYPE actype=new ACT_TYPE(null,"羽球",actt);
	    ACT_STATUS actstatis=new ACT_STATUS(null,"未開始報名",actt);
	    
	    DOS_PICTURE dos_p1=new DOS_PICTURE(null,null);//一對一 (DOS and DOS_Picture)
	    Set<DOS_PICTURE>   setp1 = new HashSet<>(Arrays.asList(dos_p1));
	    DOS_PICTURE dos_p2=new DOS_PICTURE(null,null);//一對一 (DOS and DOS_Picture)
	    Set<DOS_PICTURE>   setp2 = new HashSet<>(Arrays.asList(dos_p2));
	    DOS_PICTURE dos_p3=new DOS_PICTURE(null,null);//一對一 (DOS and DOS_Picture)
	    Set<DOS_PICTURE>   setp3 = new HashSet<>(Arrays.asList(dos_p3));
	    DOS_PICTURE dos_p4=new DOS_PICTURE(null,null);//一對一 (DOS and DOS_Picture)
	    Set<DOS_PICTURE>   setp4 = new HashSet<>(Arrays.asList(dos_p4));
	    DOS dos1=new DOS(null, "百齡球場", "新光路1段166號旁", 5001, "xxx", "xxx", "0666", 100, null, null,setp1,actt);
	    DOS dos2=new DOS(null, "道南球場", "新光路1段166號旁", 10002, "xxx", "xxx", "0666", 100, null, null,setp2,null);
	    DOS dos3=new DOS(null, "百齡球場1", "新光路1段166號旁", 5003, "xxx", "xxx", "0666", 100, null, null,setp3,null);
	    DOS dos4=new DOS(null, "道南球場1", "新光路1段166號旁", 10004, "xxx", "xxx", "0666", 100, null, null,setp4,null);
	    Set<DOS>   set1 = new HashSet<>(Arrays.asList(dos1,dos2));//一對多
	    DOS_SPORT dept1 = new DOS_SPORT(null,"羽球", set1);
	    Set<DOS>   set2 = new HashSet<>(Arrays.asList(dos3,dos4));//一對多
	    DOS_SPORT dept2 = new DOS_SPORT(null,"籃球", set2);
        System.out.println("--------------------------------------");
        session.persist(actype);
        session.persist(actstatis);
        session.persist(dos_p1);
        session.persist(dos_p2);
        session.persist(dos_p3);
        session.persist(dos_p4);
        session.persist(dept1);
        session.persist(dept2);
		tx.commit();
		session.close();
		System.out.println("程式結束(Done...!!)");
		factory.close();

	}

}
