package DOS.main;

import java.util.List;

import javax.persistence.NoResultException;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import DOS.model.DOS;
import DOS.model.DOS_PICTURE;
import DOS.util.HibernateUtils;

public class DOS_Main_Query {

	public DOS_Main_Query() {
	}
	public static void main(String[] args) {
		//List<DOS_PICTURE> result= null;
		DOS dept=null;
		//DOS_PICTURE dp=null;
		//byte[] sImage = null;
		SessionFactory factory = HibernateUtils.getSessionFactory();
		Session session=factory.getCurrentSession();
		Transaction tx=null;
		//String hql = "Select  DOS_PICTURE_PIC FROM DOS_PICTURE dp WHERE dp.dos_id = :dosid ";
		
		try {
			tx=session.beginTransaction();
			dept = session.get(DOS.class, 1);
			if (dept != null) {
				for (DOS_PICTURE dosp : dept.getDos_picture()) {
					System.out.println("發現ㄧ個圖片"+dosp.getDOS_PICTURE_ID());
					//result.add(dosp);				
			   }
			} else {
				System.out.println("查無資料");
			}
			//System.out.print(result.size());
			//result.add(dept);
//			sImage=temp.getDOS_PICTURE_PIC();
//			temp.setDOS_PICTURE_PIC((sImage));
			tx.commit();
		}catch(NoResultException ex) {
			dept=null;
			if(tx!=null) {
				tx.rollback();
			}
			ex.printStackTrace();
			throw new RuntimeException(ex);
		}
	}

}
