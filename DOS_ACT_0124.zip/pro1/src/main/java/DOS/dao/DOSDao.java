//dao(盡可能只寫sql資料)
//hibernate需有交易,web-inf需有lib,bind必備,jstl1.2以上需引號
package DOS.dao;



import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.Base64;
import java.util.List;
import java.util.Vector;

import javax.persistence.NoResultException;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import DOS.model.DOS;
import DOS.model.DOS_PICTURE;
import DOS.util.HibernateUtils;











public class DOSDao {
	SessionFactory factory;
	
	public DOSDao() {
		this.factory=HibernateUtils.getSessionFactory();
	}
	//查詢所有場地
	@SuppressWarnings("unchecked")
	public List<DOS> select() {
		List<DOS> dos = null;
		Session session=factory.getCurrentSession();
		Transaction tx=null;
		String hql = "FROM DOS  ";
		
		try {
			tx=session.beginTransaction();
			dos=session.createQuery(hql).list();
			tx.commit();
		}catch(NoResultException ex) {
			dos=null;
			if(tx!=null) {
				tx.rollback();
			}
			ex.printStackTrace();
			throw new RuntimeException(ex);
		}
		return dos;
	}
	
	
	
	//依據編號查詢場地
	//private static final String SELECT_BY_ID = "Select  DOS_NAME, DOS_ADDR, DOS_CY, DOS_PHONE, DOS_PAY, DOS_PIC from dos where DOS_ID = ?";

	public DOS selectid(int  dOSID) {
		DOS dos = null;
		Session session=factory.getCurrentSession();
		Transaction tx=null;
		String hql = "FROM DOS d WHERE d.DOS_ID = :dosid ";
		
		try {
			tx=session.beginTransaction();
			dos=(DOS) session.createQuery(hql).setParameter("dosid", dOSID).getSingleResult();
			tx.commit();
		}catch(NoResultException ex) {
			dos=null;
			if(tx!=null) {
				tx.rollback();
			}
			ex.printStackTrace();
			throw new RuntimeException(ex);
		}
		return dos;
	}
	
	
	
	//查詢此場地的相片集
	//private static final String SELECT_ALLPIC_ID = "Select  DOS_PICTURE_PIC from dos_picture where DOS_ID = ?";
	
	@SuppressWarnings("null")
	public List<DOS_PICTURE> selecallpic(int  dOSID) {
		List<DOS_PICTURE> result= null;
		
		//DOS_PICTURE dp=null;
		byte[] sImage = null;
		Session session=factory.getCurrentSession();
		Transaction tx=null;
		//String hql = "Select  DOS_PICTURE_PIC FROM DOS_PICTURE dp WHERE dp.dos_id = :dosid ";
		
		try {
			tx=session.beginTransaction();
			
			DOS dept = session.get(DOS.class, dOSID);
			result=new Vector<DOS_PICTURE>();
			if (dept != null) {
				for (DOS_PICTURE dosp : dept.getDos_picture()) {
					System.out.println("發現ㄧ個員工"+dosp.getDOS_PICTURE_ID());
					result.add(dosp);				
			   }
			} else {
				System.out.println("查無資料");
			}
			System.out.print(result.size());
			//result.add(dept);
//			sImage=temp.getDOS_PICTURE_PIC();
//			temp.setDOS_PICTURE_PIC((sImage));
			tx.commit();
		}catch(NoResultException ex) {
			result=null;
			if(tx!=null) {
				tx.rollback();
			}
			ex.printStackTrace();
			throw new RuntimeException(ex);
		}
//					DOSPICBean temp = new DOSPICBean();
//					sImage = rset.getBytes("DOS_PICTURE_PIC");
//					temp.setDOS_PICTURE_PIC(Base64.getEncoder().encodeToString(sImage));
//					result.add(temp);
				
		
		return result;
	}
}
