package DOS.model;

import java.io.Serializable;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

//單向一對多 可以從運動種類找到場地
@Entity
@Table(name="DOS_SPORT")
public class DOS_SPORT implements Serializable{
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer DOS_SPORT_ID;
	private String DOS_SPORT_NAME;
	@OneToMany(cascade = CascadeType.PERSIST, orphanRemoval = true)
	@JoinColumn(name = "FK_DOS_SPORT_ID", referencedColumnName = "DOS_SPORT_ID")
	//對DOS新增欄位外鍵
	private Set<DOS> dos = new LinkedHashSet<>();
	public Set<DOS> getDos() {
		return dos;
	}


	public void setDos(Set<DOS> dos) {
		this.dos = dos;
	}


	public DOS_SPORT() {
		// TODO Auto-generated constructor stub
	}
	

	public DOS_SPORT(Integer dOS_SPORT_ID, String dOS_SPORT_NAME, Set<DOS> dos) {
		super();
		DOS_SPORT_ID = dOS_SPORT_ID;
		DOS_SPORT_NAME = dOS_SPORT_NAME;
		this.dos = dos;
	}


	public Integer getDOS_SPORT_ID() {
		return DOS_SPORT_ID;
	}
	public void setDOS_SPORT_ID(Integer dOS_SPORT_ID) {
		DOS_SPORT_ID = dOS_SPORT_ID;
	}
	public String getDOS_SPORT_NAME() {
		return DOS_SPORT_NAME;
	}
	public void setDOS_SPORT_NAME(String dOS_SPORT_NAME) {
		DOS_SPORT_NAME = dOS_SPORT_NAME;
	}

}
