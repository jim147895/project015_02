//model
package DOS.model;


import java.io.Serializable;
import java.sql.Clob;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import ACT.model.ACT;

@Entity
@Table(name="DOS")
public class DOS implements Serializable{
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer DOS_ID;
	private String DOS_NAME;   			
	private String DOS_ADDR;   			
	private int DOS_CY;       			
	//private Integer DOS_SPORT_ID;
	//private Integer DOS_PICTURE_ID;
	private String DOS_CON_AD;
	private String DOS_CON_OFFICER;
	private String DOS_CON_PHONE;
	private double DOS_PAY;
	private Clob DOS_TRAFFIC;
	private Clob DOS_PS;
	//單向一對多，可從場地找到多張照片
	@OneToMany(cascade = CascadeType.PERSIST, orphanRemoval = true)
	@JoinColumn(name = "FK_DOS_ID", referencedColumnName = "DOS_ID")
	//對DOS_PICTURE新增欄位外鍵
	private Set<DOS_PICTURE> dos_picture = new LinkedHashSet<>();
	//單向一對多，可從場地找到目前正在進行的活動
	@OneToMany(cascade = CascadeType.PERSIST, orphanRemoval = true)
	@JoinColumn(name = "FK_DOS_ID", referencedColumnName = "DOS_ID")
	//對ACT新增欄位外鍵
	private Set<ACT> act = new LinkedHashSet<>();
	public DOS() {
		
	}

	public DOS(Integer dOS_ID, String dOS_NAME, String dOS_ADDR, int dOS_CY, String dOS_CON_AD, String dOS_CON_OFFICER,
			String dOS_CON_PHONE, double dOS_PAY, Clob dOS_TRAFFIC, Clob dOS_PS, Set<DOS_PICTURE> dos_picture) {
		super();
		DOS_ID = dOS_ID;
		DOS_NAME = dOS_NAME;
		DOS_ADDR = dOS_ADDR;
		DOS_CY = dOS_CY;
		DOS_CON_AD = dOS_CON_AD;
		DOS_CON_OFFICER = dOS_CON_OFFICER;
		DOS_CON_PHONE = dOS_CON_PHONE;
		DOS_PAY = dOS_PAY;
		DOS_TRAFFIC = dOS_TRAFFIC;
		DOS_PS = dOS_PS;
		this.dos_picture = dos_picture;
	}







	public DOS(Integer dOS_ID, String dOS_NAME, String dOS_ADDR, int dOS_CY, String dOS_CON_AD, String dOS_CON_OFFICER,
			String dOS_CON_PHONE, double dOS_PAY, Clob dOS_TRAFFIC, Clob dOS_PS, Set<DOS_PICTURE> dos_picture,
			Set<ACT> act) {
		super();
		DOS_ID = dOS_ID;
		DOS_NAME = dOS_NAME;
		DOS_ADDR = dOS_ADDR;
		DOS_CY = dOS_CY;
		DOS_CON_AD = dOS_CON_AD;
		DOS_CON_OFFICER = dOS_CON_OFFICER;
		DOS_CON_PHONE = dOS_CON_PHONE;
		DOS_PAY = dOS_PAY;
		DOS_TRAFFIC = dOS_TRAFFIC;
		DOS_PS = dOS_PS;
		this.dos_picture = dos_picture;
		this.act = act;
	}







	public Set<DOS_PICTURE> getDos_picture() {
		return dos_picture;
	}

	public void setDos_picture(Set<DOS_PICTURE> dos_picture) {
		this.dos_picture = dos_picture;
	}

	public Set<ACT> getAct() {
		return act;
	}



	public void setAct(Set<ACT> act) {
		this.act = act;
	}



	public Integer getDOS_ID() {
		return DOS_ID;
	}

	public void setDOS_ID(Integer dOS_ID) {
		DOS_ID = dOS_ID;
	}

	public String getDOS_NAME() {
		return DOS_NAME;
	}

	public void setDOS_NAME(String dOS_NAME) {
		DOS_NAME = dOS_NAME;
	}

	public String getDOS_ADDR() {
		return DOS_ADDR;
	}

	public void setDOS_ADDR(String dOS_ADDR) {
		DOS_ADDR = dOS_ADDR;
	}

	public int getDOS_CY() {
		return DOS_CY;
	}

	public void setDOS_CY(int dOS_CY) {
		DOS_CY = dOS_CY;
	}

//	public Integer getDOS_SPORT_ID() {
//		return DOS_SPORT_ID;
//	}
//
//	public void setDOS_SPORT_ID(Integer dOS_SPORT_ID) {
//		DOS_SPORT_ID = dOS_SPORT_ID;
//	}

//	public Integer getDOS_PICTURE_ID() {
//		return DOS_PICTURE_ID;
//	}
//
//	public void setDOS_PICTURE_ID(Integer dOS_PICTURE_ID) {
//		DOS_PICTURE_ID = dOS_PICTURE_ID;
//	}

	public String getDOS_CON_AD() {
		return DOS_CON_AD;
	}

	public void setDOS_CON_AD(String dOS_CON_AD) {
		DOS_CON_AD = dOS_CON_AD;
	}

	public String getDOS_CON_OFFICER() {
		return DOS_CON_OFFICER;
	}

	public void setDOS_CON_OFFICER(String dOS_CON_OFFICER) {
		DOS_CON_OFFICER = dOS_CON_OFFICER;
	}

	public String getDOS_CON_PHONE() {
		return DOS_CON_PHONE;
	}

	public void setDOS_CON_PHONE(String dOS_CON_PHONE) {
		DOS_CON_PHONE = dOS_CON_PHONE;
	}

	public double getDOS_PAY() {
		return DOS_PAY;
	}

	public void setDOS_PAY(double dOS_PAY) {
		DOS_PAY = dOS_PAY;
	}

	public Clob getDOS_TRAFFIC() {
		return DOS_TRAFFIC;
	}

	public void setDOS_TRAFFIC(Clob dOS_TRAFFIC) {
		DOS_TRAFFIC = dOS_TRAFFIC;
	}

	public Clob getDOS_PS() {
		return DOS_PS;
	}

	public void setDOS_PS(Clob dOS_PS) {
		DOS_PS = dOS_PS;
	}
	
	
	
	
}
