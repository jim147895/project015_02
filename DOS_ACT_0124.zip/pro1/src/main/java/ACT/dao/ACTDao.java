//dao(盡可能只寫sql語法)
package ACT;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.List;
import java.util.Vector;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;



public class ACTDao {
	
DataSource ds = null;
	
	public ACTDao() {
		try {
			Context context = new InitialContext();
			ds = (DataSource) context.lookup("java:comp/env/jdbc/MemberDB");
		} catch (NamingException e) {
			e.printStackTrace();
		}
	}	
	//加入一筆活動資料
	private static final String SELECT_BY = 
			"insert into act_main(DOS_ID,ACT_MAIN_TITLE,ACT_MAIN_DESC,"
			+ "ACT_MAIN_PERSON,ACT_MAIN_OPENING,ACT_MAIN_CLOSING,ACT_MAIN_TIME,ACT_MAIN_PAY,status1) values(?,?,?,?,?,?,?,?,?)";

	public void selectid(ACT_MAIN act_bean) throws ParseException, SQLException {
//		ACTBean temp = null;
		//String[] ss = date.split("\\s+"); 
		//ss[1]=ss[1].substring(0,5);//時間
//		 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
//		 java.util.Date cdate = sdf.parse(ss[0]);
//		 java.sql.Date sqlDate = new Date(cdate.getTime());		 
		 SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-mm-dd hh:mm:00");
		 java.util.Date cdate1 = sdf1.parse(act_bean.getACT_MAIN_OPENING());
		 Timestamp ts = new Timestamp(cdate1.getTime());
		 
		 SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-mm-dd hh:mm:00");
		 java.util.Date cdate2 = sdf2.parse(act_bean.getACT_MAIN_CLOSING());
		 Timestamp ts1 = new Timestamp(cdate2.getTime());
		 
		 SimpleDateFormat sdf3 = new SimpleDateFormat("yyyy-mm-dd hh:mm:00");
		 java.util.Date cdate3 = sdf3.parse(act_bean.getACT_MAIN_TIME());
		 Timestamp ts2 = new Timestamp(cdate3.getTime());
		  
		try(
				Connection conn = ds.getConnection();
				PreparedStatement stmt = conn.prepareStatement(SELECT_BY);
			){
//			 java.sql.Date date1=java.sql.Date.valueOf(ss[0]);
			stmt.setInt(1, act_bean.getDOS_ID());
			stmt.setString(2, act_bean.getACT_MAIN_TITLE());
			stmt.setString(3, act_bean.getACT_MAIN_DESC());
			stmt.setInt(4,act_bean.getACT_MAIN_PERSON());
			stmt.setTimestamp(5, ts);
			stmt.setTimestamp(6, ts1);
			stmt.setTimestamp(7, ts2);
			stmt.setInt(8, act_bean.getACT_MAIN_PAY());
			stmt.setString(9,act_bean.getStatus());
			stmt.executeUpdate();		
		}		
	}
	//針對開放跟截止時間做報名判斷
	public String selectid1(String ACT_MAIN_OPENING,String ACT_MAIN_CLOSING) throws ParseException, SQLException {
		String s=null;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:00");
	    java.util.Date date = new java.util.Date();
	    String current=sdf.format(date);
	    System.out.println("The current date is : " + current);
	    System.out.println("The current date is : " + (ACT_MAIN_OPENING));
	    System.out.println("The current date is : " + (ACT_MAIN_CLOSING));
	    int result=current.compareTo(ACT_MAIN_OPENING);
		int result1=current.compareTo(ACT_MAIN_CLOSING);
		System.out.println(result);
		System.out.println(result1);
		if(result<0 && result1<0) {
			s="還不能報名";
		}
		else if(result>=0 && result1<=0) {
			s="報名中";
		}
		else {
			s="已截止";
		}		
		return s;		
	}
	
	//分頁(計數所有資料)
	private static final String  Select2 ="SELECT count(*) from  act_main";
	public int select2() throws SQLException {
	int count=0;
	try(
			Connection conn = ds.getConnection();
			PreparedStatement stmt = conn.prepareStatement(Select2);
			ResultSet rset = stmt.executeQuery();				
		){
		if(rset.next()) {
			count=rset.getInt(1);
			//System.out.println("count:"+count);
		}
	}
	return count;
	}
	
//	public List<ACT_Bean> select4() throws SQLException, ParseException{
//		return select4(0, Short.MAX_VALUE);
//	}

    //取得商品第X筆-第X筆資料
	String select3 = "select * from act_main order by ACT_MAIN_ID desc limit ?,? ";
	public List<ACT_MAIN> select4(int start, int count) throws SQLException, ParseException {
		List<ACT_MAIN> result = null;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:00");
		try(
				Connection conn = ds.getConnection();
				PreparedStatement stmt = conn.prepareStatement(select3);								
			){
			result = new Vector<>();
			stmt.setInt(1, start);
			stmt.setInt(2, count);
		    ResultSet rset=stmt.executeQuery();
			while(rset.next()) {
				ACT_MAIN temp=new ACT_MAIN();
				temp.setACT_MAIN_ID(rset.getInt(1));
				temp.setDOS_ID(rset.getInt(2));
				temp.setACT_MAIN_TITLE(rset.getString(3));
				temp.setACT_MAIN_DESC(rset.getString(4));
				temp.setACT_MAIN_PERSON(rset.getInt(5));
				temp.setACT_MAIN_OPENING(sdf.format(rset.getTimestamp(6)));
				temp.setACT_MAIN_CLOSING(sdf.format(rset.getTimestamp(7)));
				temp.setACT_MAIN_TIME(sdf.format(rset.getTimestamp(8)));
				temp.setACT_MAIN_PAY(rset.getInt(9));
				temp.setStatus(rset.getString(10));
//				temp.setDOS_PIC(rset.getBinaryStream("DOS_PIC"));
				result.add(temp);				
			}
		}
		return result;
	}
}
