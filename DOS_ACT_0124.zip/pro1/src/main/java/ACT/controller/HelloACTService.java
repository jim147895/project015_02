//controller
package ACT;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import login.model.LoginBean;


//查詢全部活動資料+分頁
@WebServlet("/ACT/HelloACTService")
public class HelloACTService extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		LoginBean mb = (LoginBean) session.getAttribute("LoginOK");
		int start=0;
		int count=5;
		int total=0;
		try {
			total = new ACTService().getallAct_count();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
		    start = Integer.parseInt(request.getParameter("start"));//取得jsp上的start參數 
		}catch (NumberFormatException e) {
            System.out.println("沒有起始值");
        }
		//response.setHeader( "Refresh" ,"10" );
	    response.setCharacterEncoding("UTF-8");	
	    //0+5=5，下一頁就從第5筆開始
	    int next=start+count;
	    //5-5=0，上一頁就從第0筆開始
	    int pre=start-count;
	    
	    int last;
	    //總共10筆資料 每頁5個 ，則最後一頁開始就是第5筆
	    if(total % count == 0) {
	    	last=total-count;
	    //總共21筆資料 每頁5個，則最後一頁開始就是第20筆
	    }else {
	    	last=total-total%count;
	    }
	    //邊界
	    pre=pre<0 ? 0 : pre;
	    next=next>last ? last : next;
	    List<ACT_MAIN> act_all=null;
		try {
			act_all = new ACTService().select4(start,count);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
	    request.setAttribute("next", next);	//下一頁
	    request.setAttribute("pre", pre);	//上一頁
	    request.setAttribute("last",last);	//最後一頁
	    request.setAttribute("Act", act_all);
	    RequestDispatcher rd =                       		
	         request.getRequestDispatcher("ACT_Detail.jsp");
	         rd.forward(request, response);               		
	    return ;                                     		
	    } 	
}

