package ACT.model;

import java.io.Serializable;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
//單向一對多 可以從活動種類找到所有活動
@Entity
@Table(name="ACT_TYPE")
public class ACT_TYPE implements Serializable{
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer ACT_TYPE_ID;
    private String ACT_TYPE_NAME;
    
    @OneToMany(cascade = CascadeType.PERSIST, orphanRemoval = true)
	@JoinColumn(name = "FK_ACT_TYPE_ID", referencedColumnName = "ACT_TYPE_ID")
	//對ACT新增欄位外鍵
	private Set<ACT> act = new LinkedHashSet<>();
	public ACT_TYPE() {
		// TODO Auto-generated constructor stub
	}
	public ACT_TYPE(Integer aCT_TYPE_ID, String aCT_TYPE_NAME, Set<ACT> act) {
		super();
		ACT_TYPE_ID = aCT_TYPE_ID;
		ACT_TYPE_NAME = aCT_TYPE_NAME;
		this.act = act;
	}
	public Integer getACT_TYPE_ID() {
		return ACT_TYPE_ID;
	}
	public void setACT_TYPE_ID(Integer aCT_TYPE_ID) {
		ACT_TYPE_ID = aCT_TYPE_ID;
	}
	public String getACT_TYPE_NAME() {
		return ACT_TYPE_NAME;
	}
	public void setACT_TYPE_NAME(String aCT_TYPE_NAME) {
		ACT_TYPE_NAME = aCT_TYPE_NAME;
	}
	public Set<ACT> getAct() {
		return act;
	}
	public void setAct(Set<ACT> act) {
		this.act = act;
	}
    
}
