//model
package ACT.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ACT")
public class ACT implements Serializable{
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer ACT_ID;
	private Integer MEMBER_ID;
	//private int DOS_ID;由DOS新增外鍵
	private String ACT_TITLE;
	private String ACT_DESC;
	private int ACT_MAX_PNUM;
	private String ACT_SIGN_O;
	private String ACT_SIGN_C;
	private String ACT_RUN_O;
	private String ACT_RUN_C;
	private int ACT_PAY;
	//private int ACT_TYPE_ID;由ACT_TYPE新增外鍵
	//private int DOS_SPORT_ID;不必要
	//private int ACT_STATUS_ID;由ACT_STATUS新增外鍵
	private int ACT_PNUM;
	public ACT() {
		
	}
	public ACT(Integer aCT_ID, Integer mEMBER_ID, String aCT_TITLE, String aCT_DESC, int aCT_MAX_PNUM,
			String aCT_SIGN_O, String aCT_SIGN_C, String aCT_RUN_O, String aCT_RUN_C, int aCT_PAY, int aCT_PNUM) {
		super();
		ACT_ID = aCT_ID;
		MEMBER_ID = mEMBER_ID;
		ACT_TITLE = aCT_TITLE;
		ACT_DESC = aCT_DESC;
		ACT_MAX_PNUM = aCT_MAX_PNUM;
		ACT_SIGN_O = aCT_SIGN_O;
		ACT_SIGN_C = aCT_SIGN_C;
		ACT_RUN_O = aCT_RUN_O;
		ACT_RUN_C = aCT_RUN_C;
		ACT_PAY = aCT_PAY;
		ACT_PNUM = aCT_PNUM;
	}
	public Integer getACT_ID() {
		return ACT_ID;
	}
	public void setACT_ID(Integer aCT_ID) {
		ACT_ID = aCT_ID;
	}
	public Integer getMEMBER_ID() {
		return MEMBER_ID;
	}
	public void setMEMBER_ID(Integer mEMBER_ID) {
		MEMBER_ID = mEMBER_ID;
	}
	public String getACT_TITLE() {
		return ACT_TITLE;
	}
	public void setACT_TITLE(String aCT_TITLE) {
		ACT_TITLE = aCT_TITLE;
	}
	public String getACT_DESC() {
		return ACT_DESC;
	}
	public void setACT_DESC(String aCT_DESC) {
		ACT_DESC = aCT_DESC;
	}
	public int getACT_MAX_PNUM() {
		return ACT_MAX_PNUM;
	}
	public void setACT_MAX_PNUM(int aCT_MAX_PNUM) {
		ACT_MAX_PNUM = aCT_MAX_PNUM;
	}
	public String getACT_SIGN_O() {
		return ACT_SIGN_O;
	}
	public void setACT_SIGN_O(String aCT_SIGN_O) {
		ACT_SIGN_O = aCT_SIGN_O;
	}
	public String getACT_SIGN_C() {
		return ACT_SIGN_C;
	}
	public void setACT_SIGN_C(String aCT_SIGN_C) {
		ACT_SIGN_C = aCT_SIGN_C;
	}
	public String getACT_RUN_O() {
		return ACT_RUN_O;
	}
	public void setACT_RUN_O(String aCT_RUN_O) {
		ACT_RUN_O = aCT_RUN_O;
	}
	public String getACT_RUN_C() {
		return ACT_RUN_C;
	}
	public void setACT_RUN_C(String aCT_RUN_C) {
		ACT_RUN_C = aCT_RUN_C;
	}
	public int getACT_PAY() {
		return ACT_PAY;
	}
	public void setACT_PAY(int aCT_PAY) {
		ACT_PAY = aCT_PAY;
	}
	public int getACT_PNUM() {
		return ACT_PNUM;
	}
	public void setACT_PNUM(int aCT_PNUM) {
		ACT_PNUM = aCT_PNUM;
	}
	
	

	
}
