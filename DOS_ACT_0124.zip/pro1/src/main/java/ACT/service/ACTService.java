//service
package ACT;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;



public class ACTService {
	
    ACTDao dao = null;
	
	public ACTService() {
		dao = new ACTDao();
	}	

	public void selectid(ACT_MAIN act_bean) throws ParseException, SQLException {
		dao.selectid(act_bean);
	}
	
	public String selectid1(String ACT_MAIN_OPENING,String ACT_MAIN_CLOSING) throws ParseException, SQLException  {
		return dao.selectid1(ACT_MAIN_OPENING,ACT_MAIN_CLOSING);
	}
	
	public int getallAct_count() throws SQLException {
		return dao.select2();
	}
	
	public List<ACT_MAIN> select4(int start, int count) throws ParseException, SQLException {
		return dao.select4(start,count);
	}
//	public List<ACT_Bean> getallList() throws SQLException, ParseException{
//		return dao.select4();
//	}
}
