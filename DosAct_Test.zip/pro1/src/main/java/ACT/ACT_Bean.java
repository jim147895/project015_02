//model
package ACT;

import java.io.Serializable;


public class ACT_Bean implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private int ACT_MAIN_ID;
	private int DOS_ID;
	private String ACT_MAIN_TITLE;
	private String ACT_MAIN_DESC;
	private int ACT_MAIN_PERSON;
	private String ACT_MAIN_OPENING;
	private String ACT_MAIN_CLOSING;
	private String ACT_MAIN_TIME;
	private int ACT_MAIN_PAY;
	private String status;
	public ACT_Bean() {
		
	}
	public ACT_Bean(int dOS_ID, String aCT_MAIN_TITLE, String aCT_MAIN_DESC, int aCT_MAIN_PERSON,
			String aCT_MAIN_OPENING, String aCT_MAIN_CLOSING, String aCT_MAIN_TIME, int aCT_MAIN_PAY,String status) {
		super();
		DOS_ID = dOS_ID;
		setACT_MAIN_TITLE(aCT_MAIN_TITLE);
		setACT_MAIN_DESC(aCT_MAIN_DESC);
		setACT_MAIN_PERSON(aCT_MAIN_PERSON);
		setACT_MAIN_OPENING(aCT_MAIN_OPENING);
		setACT_MAIN_CLOSING(aCT_MAIN_CLOSING);
		setACT_MAIN_TIME(aCT_MAIN_TIME);
		setACT_MAIN_PAY(aCT_MAIN_PAY);
		setStatus(status);
	}
	public int getDOS_ID() {
		return DOS_ID;
	}
	public void setDOS_ID(int dOS_ID) {
		DOS_ID = dOS_ID;
	}
	public String getACT_MAIN_TITLE() {
		return ACT_MAIN_TITLE;
	}
	public void setACT_MAIN_TITLE(String aCT_MAIN_TITLE) {
		ACT_MAIN_TITLE = aCT_MAIN_TITLE;
	}
	public String getACT_MAIN_DESC() {
		return ACT_MAIN_DESC;
	}
	public void setACT_MAIN_DESC(String aCT_MAIN_DESC) {
		ACT_MAIN_DESC = aCT_MAIN_DESC;
	}
	public int getACT_MAIN_PERSON() {
		return ACT_MAIN_PERSON;
	}
	public void setACT_MAIN_PERSON(int aCT_MAIN_PERSON) {
		ACT_MAIN_PERSON = aCT_MAIN_PERSON;
	}
	public String getACT_MAIN_OPENING() {
		return ACT_MAIN_OPENING;
	}
	public void setACT_MAIN_OPENING(String aCT_MAIN_OPENING) {
		ACT_MAIN_OPENING = aCT_MAIN_OPENING;
	}
	public String getACT_MAIN_CLOSING() {
		return ACT_MAIN_CLOSING;
	}
	public void setACT_MAIN_CLOSING(String aCT_MAIN_CLOSING) {
		ACT_MAIN_CLOSING = aCT_MAIN_CLOSING;
	}
	public String getACT_MAIN_TIME() {
		return ACT_MAIN_TIME;
	}
	public void setACT_MAIN_TIME(String aCT_MAIN_TIME) {
		ACT_MAIN_TIME = aCT_MAIN_TIME;
	}
	public int getACT_MAIN_PAY() {
		return ACT_MAIN_PAY;
	}
	public void setACT_MAIN_PAY(int aCT_MAIN_PAY) {
		ACT_MAIN_PAY = aCT_MAIN_PAY;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getACT_MAIN_ID() {
		return ACT_MAIN_ID;
	}
	public void setACT_MAIN_ID(int aCT_MAIN_ID) {
		ACT_MAIN_ID = aCT_MAIN_ID;
	}
}
