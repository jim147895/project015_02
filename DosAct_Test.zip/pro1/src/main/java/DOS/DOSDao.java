//dao(盡可能只寫sql資料)
package DOS;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Base64;
import java.util.List;
import java.util.Vector;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;





public class DOSDao {
DataSource ds = null;
	
	public DOSDao() {
		try {
			Context context = new InitialContext();
			ds = (DataSource) context.lookup("java:comp/env/jdbc/MemberDB");
		} catch (NamingException e) {
			e.printStackTrace();
		}
	}
	//查詢所有場地
	private static final String  Select1 ="SELECT * from  dos";
	public List<DOSBean> select() {
		List<DOSBean> result = null;
		try(
			Connection conn = ds.getConnection();
			PreparedStatement stmt = conn.prepareStatement(Select1);
			ResultSet rset = stmt.executeQuery();				
		) {
			result = new Vector<>();
			byte[] sImage = null;
			while (rset.next()) {
				DOSBean temp = new DOSBean();
				temp.setDOS_ID(rset.getInt(1));
				temp.setDOS_NAME(rset.getString("DOS_NAME"));
				temp.setDOS_ADDR(rset.getString("DOS_ADDR"));
				temp.setDOS_CY(rset.getInt("DOS_CY"));
				temp.setDOS_PHONE(rset.getString("DOS_PHONE"));
				temp.setDOS_PAY(rset.getInt("DOS_PAY"));
				sImage = rset.getBytes("DOS_PIC");
				temp.setDOS_PIC(Base64.getEncoder().encodeToString(sImage));
//				temp.setDOS_PIC(rset.getBinaryStream("DOS_PIC"));
				result.add(temp);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} 
		return result;
	}
	
	
	
	//依據編號查詢場地
	private static final String SELECT_BY_ID = "Select  DOS_NAME, DOS_ADDR, DOS_CY, DOS_PHONE, DOS_PAY, DOS_PIC from dos where DOS_ID = ?";

	public DOSBean selectid(int  dOSID) {
		DOSBean temp = null;
		byte[] sImage = null;
		try(
			Connection conn = ds.getConnection();
			PreparedStatement stmt = conn.prepareStatement(SELECT_BY_ID);
		) {
			stmt.setInt(1, dOSID);
			try (
				ResultSet rset = stmt.executeQuery();					
			){
				if (rset.next()) {
					temp = new DOSBean();
					temp.setDOS_ID(dOSID);
					temp.setDOS_NAME(rset.getString("DOS_NAME"));
					temp.setDOS_ADDR(rset.getString("DOS_ADDR"));
					temp.setDOS_CY(rset.getInt("DOS_CY"));
					temp.setDOS_PHONE(rset.getString("DOS_PHONE"));
					temp.setDOS_PAY(rset.getInt("DOS_PAY"));
					sImage = rset.getBytes("DOS_PIC");
					temp.setDOS_PIC(Base64.getEncoder().encodeToString(sImage));
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} 
		return temp;
	}
	
	//查詢此場地的相片集
	private static final String SELECT_ALLPIC_ID = "Select  DOS_PICTURE_PIC from dos_picture where DOS_ID = ?";
	
	public List<DOSPICBean> selecallpic(int  dOSID) {
		List<DOSPICBean> result= null;
		byte[] sImage = null;
		try(
			Connection conn = ds.getConnection();
			PreparedStatement stmt = conn.prepareStatement(SELECT_ALLPIC_ID);
		) {
			stmt.setInt(1, dOSID);
			try (
				ResultSet rset = stmt.executeQuery();					
			){
				result = new Vector<>();
				while (rset.next()) {
					DOSPICBean temp = new DOSPICBean();
					sImage = rset.getBytes("DOS_PICTURE_PIC");
					temp.setDOS_PICTURE_PIC(Base64.getEncoder().encodeToString(sImage));
					result.add(temp);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.out.print(result.size());
		return result;
	}
}
