//service
package DOS;

import java.util.List;

public class DOSService {
    DOSDao dao = null;
	
	public DOSService() {
		dao = new DOSDao();
	}	

	public List<DOSBean> select() {
		return dao.select();
	}
	
	public DOSBean selectid(int dOSID) {
		return dao.selectid(dOSID);
	}
	public List<DOSPICBean> selecallpic(int dOSID){
		return dao.selecallpic(dOSID);
	}
}
