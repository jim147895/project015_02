//model
package DOS;


import java.io.Serializable;


public class DOSBean implements Serializable{
	private static final long serialVersionUID = 1L;
	private String DOS_NAME;   			// 帳號
	private String DOS_ADDR;   			// 密碼
	private int DOS_CY;       			// 姓名
	private String	DOS_PHONE;     			// 電話
	private double DOS_PAY;
	private String DOS_PIC;
	private int DOS_ID;
	public DOSBean() {
		
	}
	public DOSBean(String DOS_NAME,String DOS_ADDR,int DOS_CY,String DOS_PHONE,double DOS_PAY,String DOS_PIC) {
		super();
		this.setDOS_NAME((DOS_NAME));
		this.setDOS_ADDR((DOS_ADDR));
		this.setDOS_CY((DOS_CY));
		this.setDOS_PHONE((DOS_PHONE));
		this.setDOS_PAY((DOS_PAY));
		this.setDOS_PIC(( DOS_PIC));
	}
	public String getDOS_NAME() {
		return DOS_NAME;
	}
	public void setDOS_NAME(String dOS_NAME) {
		DOS_NAME = dOS_NAME;
	}
	public String getDOS_ADDR() {
		return DOS_ADDR;
	}
	public void setDOS_ADDR(String dOS_ADDR) {
		DOS_ADDR = dOS_ADDR;
	}
	public int getDOS_CY() {
		return DOS_CY;
	}
	public void setDOS_CY(int dOS_CY) {
		DOS_CY = dOS_CY;
	}
	public String getDOS_PHONE() {
		return DOS_PHONE;
	}
	public void setDOS_PHONE(String dOS_PHONE) {
		DOS_PHONE = dOS_PHONE;
	}
	public double getDOS_PAY() {
		return DOS_PAY;
	}
	public void setDOS_PAY(double dOS_PAY) {
		DOS_PAY = dOS_PAY;
	}
	public String getDOS_PIC() {
		return DOS_PIC;
	}
	public void setDOS_PIC(String string) {
		DOS_PIC = string;
	}
	public int getDOS_ID() {
		return DOS_ID;
	}
	public void setDOS_ID(int i) {
		DOS_ID = i;
	}
	
	
	
}
