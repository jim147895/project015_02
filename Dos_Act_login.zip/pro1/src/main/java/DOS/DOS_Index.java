//controller
package DOS;

import java.io.IOException;
import java.util.Collection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/DOS/DOS_Index")
/**
 * Servlet implementation class DOS_Index
 */
public class DOS_Index extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DOS_Index() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
	     	DOSService  rs = new DOSService();   
	     	Collection<DOSBean>  DOS = rs.select() ;
	     	request.setAttribute("AllDOS", DOS);

	     	RequestDispatcher rd = request.getRequestDispatcher("/DOS/SportDOS.jsp");
	     	rd.forward(request, response);
		} catch(Exception ex) {
			ex.printStackTrace();
		}
     	return ;
	}

	

}
