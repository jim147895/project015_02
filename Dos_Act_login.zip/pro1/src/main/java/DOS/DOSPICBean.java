//model
package DOS;

import java.io.Serializable;

public class DOSPICBean implements Serializable{
	private static final long serialVersionUID = 1L;
	private String DOS_PICTURE_PIC;
    public DOSPICBean() {
		
	}
    public DOSPICBean(String DOS_PIC) {
		this.DOS_PICTURE_PIC=DOS_PIC;
	}
	public String getDOS_PICTURE_PIC() {
		return DOS_PICTURE_PIC;
	}
	public void setDOS_PICTURE_PIC(String dOS_PICTURE_PIC) {
		DOS_PICTURE_PIC = dOS_PICTURE_PIC;
	}
	
}
