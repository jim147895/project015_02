//controller
package ACT;

import java.io.IOException;
import java.sql.SQLException;

import java.text.ParseException;



import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ACT/ACT_Main_Form")
public class ACT_Main_Form extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ACT_Main_Form() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		

	    // String dateString = request.getParameter("date");
	     //Date Date = request.getParameter("picker");
		
	     try {
	    	 ACTService  rs = new ACTService();
	    	 request.setCharacterEncoding("UTF-8");	
	    	 String DOS_ID = request.getParameter("DOS_ID");
	    	 String ACT_MAIN_TITLE=request.getParameter("ACT_MAIN_TITLE");
	    	 String ACT_MAIN_DESC = request.getParameter("ACT_MAIN_DESC");
	    	 String ACT_MAIN_PERSON = request.getParameter("ACT_MAIN_PERSON");
	    	 String ACT_MAIN_OPENING = request.getParameter("ACT_MAIN_OPENING");
	    	 String ACT_MAIN_CLOSING = request.getParameter("ACT_MAIN_CLOSING");
	    	 String ACT_MAIN_TIME = request.getParameter("ACT_MAIN_TIME");
	    	 String ACT_MAIN_PAY = request.getParameter("ACT_MAIN_PAY");
	    	 String s=rs.selectid1(ACT_MAIN_OPENING, ACT_MAIN_CLOSING);
	    	 ACT_Bean act_bean=new ACT_Bean(Integer.parseInt(DOS_ID),ACT_MAIN_TITLE,ACT_MAIN_DESC
	    			 ,Integer.parseInt(ACT_MAIN_PERSON),(ACT_MAIN_OPENING)
	    			 ,(ACT_MAIN_CLOSING),(ACT_MAIN_TIME),Integer.parseInt(ACT_MAIN_PAY),s);
	    	 rs.selectid(act_bean);
//	    	 rs.selectid1(ACT_MAIN_OPENING, ACT_MAIN_CLOSING);
//	    	 System.out.print(date);
//
	    	 //rs.select4();
//	    	 rs.select2();
//			request.setAttribute("ACT", act_bean);	//DOS資訊
			//request.setAttribute("ACT_List", act_list);
	    	 
//	          RequestDispatcher rd =                       		
//	                 request.getRequestDispatcher("/ACT/HelloACTService");
//	          rd.forward(request, response);
	    	 response.sendRedirect("../ACT/HelloACTService");
	    	 
	    	 
		} catch (ParseException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//	     	request.setAttribute("AllDOS", DOS);
	    
		
	}

}
