//controller
package ACT;

import java.io.IOException;
import java.io.UnsupportedEncodingException;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DOS.DOSBean;

import DOS.DOSService;
@WebServlet("/ACT/ACT_Index")
/**
 * Servlet implementation class ACT_Index
 */
public class ACT_Index extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}
    
	
	
	private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  try {
			  DOSService  rs = new DOSService();
	          request.setCharacterEncoding("UTF-8");			
	          String DOSID = request.getParameter("DOSID"); 
	          int vale=Integer.parseInt(DOSID.toString().trim()); 
	          DOSBean selectid=rs.selectid(vale);
	          
	          request.setAttribute("DOSID", selectid);	//DOS資訊
	          
	          RequestDispatcher rd =                       		
	                 request.getRequestDispatcher("/ACT/ACT_Main.jsp");
	          rd.forward(request, response);               		
	          return ;                                     		
	       } catch(UnsupportedEncodingException e) {
	          throw new ServletException(e); 
	       }

	}
}
