package login.model;

public class LoginBean {
        private String mem_count;
        private String mem_password;
        
        public LoginBean(String mem_count,String mem_password) {
        	this.mem_count=mem_count;
        	this.mem_password=mem_password;
        }
        public LoginBean() {
        	
        }
		public String getMem_count() {
			return mem_count;
		}
		public void setMem_count(String mem_count) {
			this.mem_count = mem_count;
		}
		public String getMem_password() {
			return mem_password;
		}
		public void setMem_password(String mem_password) {
			this.mem_password = mem_password;
		}
}
