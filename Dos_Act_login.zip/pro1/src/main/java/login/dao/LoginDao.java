package login.dao;

import java.sql.SQLException;

import login.model.LoginBean;

public interface LoginDao {
	public LoginBean checkIdPassword(String userId, String password) throws SQLException;
}
