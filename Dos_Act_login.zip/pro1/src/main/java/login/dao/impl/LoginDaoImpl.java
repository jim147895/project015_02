package login.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import login.dao.LoginDao;
import login.model.LoginBean;

public class LoginDaoImpl implements LoginDao{
	
DataSource ds = null;
	
	public LoginDaoImpl() {
		try {
			Context context = new InitialContext();
			ds = (DataSource) context.lookup("java:comp/env/jdbc/MemberDB");
		} catch (NamingException e) {
			e.printStackTrace();
		}
	}	
	public LoginBean checkIdPassword(String userId, String password) throws SQLException {
		LoginBean lb = null;
		String sql = "SELECT * FROM member m WHERE m.mem_account = ? and m.mem_password = ?";
		try (
			Connection con = ds.getConnection(); 
			PreparedStatement ps = con.prepareStatement(sql);
		){
			ps.setString(1, userId);
			ps.setString(2, password);
			try (ResultSet rs = ps.executeQuery();) {
				if (rs.next()) {
					lb = new LoginBean();
					lb.setMem_count(rs.getString("mem_account"));
					lb.setMem_password(rs.getString("mem_password"));
				}
			}catch (SQLException ex) {
				ex.printStackTrace();	
			}
		}
		return lb;
	}
}
