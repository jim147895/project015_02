package login.service;

import java.sql.SQLException;

import login.model.LoginBean;

public interface LoginService {
	LoginBean checkIdPassword(String userId, String password) throws SQLException;
}
